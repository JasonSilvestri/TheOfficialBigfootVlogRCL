# Jasper-Prime — Character Sheet (v1)

**Height:** 8'6" • **Build:** Barrel-chested • **Fur:** Espresso-brown matte with silver-back sheen  
**Face:** Prominent brow ridge; small rounded ears; square jaw with subtle scar

**Voice & Demeanor:** Calm, grounded; protective; few words but weighty

**Motion Notes:** Heavy but controlled gait; minimal arm swing; attention to balance on uneven forest floor

**Cinematic Cues:**
- Golden-hour forest; dappled light
- Close macros on moss, bark, and prints
- Naturalistic SFX; low music bed reserved for reveals
