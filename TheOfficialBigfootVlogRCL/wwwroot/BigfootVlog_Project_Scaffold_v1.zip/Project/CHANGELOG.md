# CHANGELOG

## [v1.0.0]
- Initialize clean scaffold for Bigfoot Vlog project.
- Add protocol, storyboard, shot cards, prompt scaffolds, and character sheet.
