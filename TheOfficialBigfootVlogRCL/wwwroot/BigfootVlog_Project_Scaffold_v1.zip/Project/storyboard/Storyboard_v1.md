# Storyboard v1

## Scene 1 — Hook (Golden Hour, Forest Clearing)
- Beat: Introduce Jasper-Prime in a New England pine clearing, dappled sun through canopy.
- Intent: Establish mood; tease mystery; hero presence.
- Notes: Soft handheld sway; naturalistic audio bed (birds, distant creek).

## Scene 3 — Escalation (Footprints by the Stream)
- Beat: Close-ups of fresh prints; Jasper-Prime silhouette in bokeh background.
- Intent: Build tension; foreshadow pursuit.
- Notes: Macro moss detail; steady macro glide.
