# TheOfficialBigfootVlogRCL — Addons v2 (PaLMs-style)

Install deps then emit docs:
```bash
npm i
npm run bf:build
npm run bf:roundtrip:win
```
